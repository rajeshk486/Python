from Parser.FindTag import *
print("ra")
#PDFreader1 = PDFreader()
#Finder1 = Finder("/home/hadoop/LegalTags.txt","/home/hadoop/ML/resume")
#PDFreader1.Extract_text()
#text="Rajeshsfs"
#print(Finder1.FindTag(PDFreader1.Extract_text()))

#D.Table_exist()
